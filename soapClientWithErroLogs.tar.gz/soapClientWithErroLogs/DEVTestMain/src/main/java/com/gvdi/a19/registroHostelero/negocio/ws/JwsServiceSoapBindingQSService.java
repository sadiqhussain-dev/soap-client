/**
 * JwsServiceSoapBindingQSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package com.gvdi.a19.registroHostelero.negocio.ws;

public interface JwsServiceSoapBindingQSService extends javax.xml.rpc.Service {
    public java.lang.String getJwsServiceSoapBindingQSPortAddress();

    public com.gvdi.a19.registroHostelero.negocio.ws.Jws getJwsServiceSoapBindingQSPort() throws javax.xml.rpc.ServiceException;

    public com.gvdi.a19.registroHostelero.negocio.ws.Jws getJwsServiceSoapBindingQSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
