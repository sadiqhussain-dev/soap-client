/**
 * Jws.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jun 14, 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package com.gvdi.a19.registroHostelero.negocio.ws;

public interface Jws extends java.rmi.Remote {
    public com.gvdi.a19.registroHostelero.negocio.ws.EnvioFicheroResponse envioFichero(com.gvdi.a19.registroHostelero.negocio.ws.EnvioFichero parameters) throws java.rmi.RemoteException, errors.negocio.oinarri.gvdi.com.BusinessException;
}
